package me.himanshu;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.CommandExecutor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

public class FloatCommandPlugin extends JavaPlugin implements CommandExecutor {

    @Override
    public void onEnable() {
        getCommand("float").setExecutor(this);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender.hasPermission("float.use"))) {
            sender.sendMessage("§cYou don't have permission to use this command.");
            return true;
        }

        if (args.length != 2) {
            sender.sendMessage("§eUsage: /float <player> <time>");
            return true;
        }

        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null || !target.isOnline()) {
            sender.sendMessage("§cPlayer not found.");
            return true;
        }

        long duration = parseTime(args[1]);
        if (duration <= 0) {
            sender.sendMessage("§cInvalid time format. Use 10s, 2m, 1m30s, etc.");
            return true;
        }

        Location loc = target.getLocation().clone();
        loc.setY(loc.getY() + 0.5);
        target.teleport(loc);
        target.setGravity(false);
        sender.sendMessage("§a" + target.getName() + " is now floating for " + args[1]);

        new BukkitRunnable() {
            @Override
            public void run() {
                target.setGravity(true);
                sender.sendMessage("§e" + target.getName() + " has stopped floating.");
            }
        }.runTaskLater(this, duration / 50); // duration is in ms, Bukkit needs ticks
        return true;
    }

    private long parseTime(String input) {
        input = input.toLowerCase();
        long total = 0;

        try {
            String[] parts = input.split("(?<=\\D)(?=\\d)|(?<=\\d)(?=\\D)");
            for (int i = 0; i < parts.length - 1; i += 2) {
                int value = Integer.parseInt(parts[i]);
                switch (parts[i + 1]) {
                    case "s": total += value * 1000L; break;
                    case "m": total += value * 60000L; break;
                }
            }
        } catch (Exception e) {
            return -1;
        }

        return total;
    }
}